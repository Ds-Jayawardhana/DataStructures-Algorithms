package graphs;

import java.util.List;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Stack;
import java.util.HashMap;
import java.util.HashSet;


public class ListGraph extends Graph {

    ArrayList<ArrayList<Integer>> adjacency;
    
    public ListGraph(int s) {
        super(s);
        adjacency = new ArrayList<>(size);
        for(int i=0; i<size; i++)
            adjacency.add(new ArrayList<>());
    }
    
    @Override
    public void addEdge(int from, int to){
        // TO DO
    }
    
    @Override
    public String toString(){
        // TO DO
        return "";
    }
    
    @Override
    public void DFS(){
	// TO DO
    }
	
    @Override
    public void BFS(){
	// TO DO
    }
    


}
