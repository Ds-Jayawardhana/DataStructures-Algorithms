package graphs;

import java.util.List;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Stack;
import java.util.HashMap;
import java.util.HashSet;

public class MatrixGraph extends Graph {

    boolean[][] adjacencyMatrix;
    
    public MatrixGraph(int s) {
        super(s);
        adjacencyMatrix = new boolean[size][size];
    }
    
    @Override
    public void addEdge(int from, int to){
        // TO DO
    }
    
    @Override
    public String toString(){
        // TO DO
        return "";
    }
    
    @Override
    public void DFS(){
	// TO DO
    }
	
    @Override
    public void BFS(){
	// TO DO
    }
    
    
}
